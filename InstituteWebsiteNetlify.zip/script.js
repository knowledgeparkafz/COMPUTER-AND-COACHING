// Replace with your Google Sheet CSV published URL
const SHEET_CSV_URL = 'https://docs.google.com/spreadsheets/d/e/YOUR_SHEET_ID/pub?output=csv';

document.getElementById('verifyForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const roll = document.getElementById('roll').value.trim();
  const dob = document.getElementById('dob').value.trim();
  const resultDiv = document.getElementById('result');
  resultDiv.innerHTML = 'Verifying...';

  try {
    const response = await fetch(SHEET_CSV_URL);
    const data = await response.text();
    const rows = data.split('\n').map(r => r.split(','));

    let found = false;
    for (let i = 1; i < rows.length; i++) {
      const [rRoll, rName, rDob, rCert] = rows[i];
      if (rRoll === roll && rDob === dob) {
        found = true;
        resultDiv.innerHTML = `<p>Name: ${rName}</p><p><a href="${rCert}" target="_blank">Download Certificate</a></p>`;
        break;
      }
    }
    if (!found) {
      resultDiv.innerHTML = '<p style="color:red">No matching record found.</p>';
    }
  } catch (err) {
    resultDiv.innerHTML = '<p style="color:red">Error fetching data.</p>';
  }
});
# Knowledge Park Institute Website

This is a simple multi-page website for Knowledge Park Institute with a student result verification system.

## Deployment on Netlify
1. Create a Google Sheet with columns: Roll | Name | DOB | CertificateLink
2. Publish the sheet to web as CSV and copy the URL.
3. Replace SHEET_CSV_URL in script.js with your published CSV link.
4. Upload this project folder to GitHub.
5. Connect your GitHub repo to Netlify and deploy.

Enjoy your live website!